
# StorageBoost Monorepo

## Përmbajtja
- **backend/** → FastAPI (Python)
- **frontend/** → React + Vite (Node.js)
- **.replit** dhe **replit.nix** → konfigurimi për Replit

## Si të ekzekutohet në Replit
1. Ngarko këtë projekt në GitHub
2. Shko në Replit → Import from GitHub
3. Run → do të startojë backend (port 8000) dhe frontend (port 5000)

Backend: http://localhost:8000  
Frontend: http://localhost:5000
