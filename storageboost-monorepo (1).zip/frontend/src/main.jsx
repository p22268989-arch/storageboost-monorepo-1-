
import React from 'react'
import ReactDOM from 'react-dom/client'

function App() {
  return <h1>Hello from React Frontend!</h1>
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
